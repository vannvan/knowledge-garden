/*
 * Description:
 * Created: 2023-02-19 22:43:32
 * Author: van
 * Email : adoerww@gamil.com
 * -----
 * Last Modified: 2023-02-19 22:43:41
 * Modified By: van
 * -----
 * Copyright (c) 2023 https://github.com/vannvan
 */
function add(a: number, b: number): number {
  return a + b
}

export default add
