/*
 * Description: 红黑树
 * Created: 2023-02-17 22:40:56
 * Author: van
 * Email : adoerww@gamil.com
 * -----
 * Last Modified: 2023-02-17 22:41:23
 * Modified By: van
 * -----
 * Copyright (c) 2023 https://github.com/vannvan
 */

class RedBlackTree {
  constructor() {
    //
  }
}
