/*
 * Description: 985：令牌放置
 * Url: https://leetcode.cn/problems/bag-of-tokens/
 * Tags: 贪心  数组  双指针  排序
 * Created: 2023-03-12 19:28:36
 * Author: van
 * Email : adoerww@gamil.com
 * -----
 * Last Modified: 2023-03-12 20:43:20
 * Modified By: van
 * -----
 * Copyright (c) 2023 https://github.com/vannvan
 */

function bagOfTokensScore(tokens: number[], power: number): number {
  // Think for yourself for 5 minutes...
  // TODO
}
export default bagOfTokensScore
