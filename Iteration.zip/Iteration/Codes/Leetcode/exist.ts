/*
 * Description: 单词搜索
 * Url: https://leetcode.cn/problems/word-search/
 * Tags: 数组  回溯  矩阵
 * Created: 2023-03-08 11:21:58
 * Author: van
 * Email : adoerww@gamil.com
 * -----
 * Last Modified: 2023-03-08 11:25:44
 * Modified By: van
 * -----
 * Copyright (c) 2023 https://github.com/vannvan
 */

function exist(board: string[][], word: string): boolean {
  // Think for yourself for 5 minutes...

  let tempStr: string = ''

  const backTrack = (board: string[][]) => {
    //
  }

  return true
}
export default exist
