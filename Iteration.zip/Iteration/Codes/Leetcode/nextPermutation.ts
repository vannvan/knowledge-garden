/*
 * Description: 下一个排列
 * Url: https://leetcode.cn/problems/next-permutation/
 * Tags: 数组  双指针
 * Created: 2023-03-08 15:14:16
 * Author: van
 * Email : adoerww@gamil.com
 * -----
 * Last Modified: 2023-03-12 17:10:40
 * Modified By: van
 * -----
 * Copyright (c) 2023 https://github.com/vannvan
 */

/**
 Do not return anything, modify nums in-place instead.
 */
function nextPermutation(nums: number[]): void {
  // Think for yourself for 5 minutes...
  // step1 从后往前找第一个将要产生递减
  // TODO
}
export default nextPermutation
