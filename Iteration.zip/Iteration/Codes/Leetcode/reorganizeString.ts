/*
 * Description: 778：重构字符串
 * Url: https://leetcode.cn/problems/reorganize-string/
 * Tags: 贪心  哈希表  字符串  计数  排序  堆（优先队列）
 * Created: 2023-03-12 16:57:57
 * Author: van
 * Email : adoerww@gamil.com
 * -----
 * Last Modified: 2023-03-12 17:10:52
 * Modified By: van
 * -----
 * Copyright (c) 2023 https://github.com/vannvan
 */

function reorganizeString(s: string): string {
  // Think for yourself for 5 minutes...
  // TODO
}
export default reorganizeString
