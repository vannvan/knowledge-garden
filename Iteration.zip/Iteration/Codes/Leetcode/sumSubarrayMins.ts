/*
 * Description: 943：子数组的最小值之和
 * Url: https://leetcode.cn/problems/sum-of-subarray-minimums/
 * Tags: 栈  数组  动态规划  单调栈
 * Created: 2023-03-21 21:46:13
 * Author: van
 * Email : adoerww@gamil.com
 * -----
 * Last Modified: 2023-03-21 22:20:29
 * Modified By: van
 * -----
 * Copyright (c) 2023 https://github.com/vannvan
 */

function sumSubarrayMins(arr: number[]): number {
  // Think for yourself for 5 minutes...
  // q1. 连续子数组
  // q2. 递进求每一个数字开头的最小值
  // TODO
}
export default sumSubarrayMins
