/*
 * Description: 112：路径总和
 * Url: https://leetcode.cn/problems/path-sum/
 * Created: 2023-04-02 18:25:09
 * Author: van
 * Email : adoerww@gamil.com
 * -----
 * Last Modified: 2023-04-02 18:31:23
 * Modified By: van
 * -----
 * Copyright (c) 2023 https://github.com/vannvan
 */
import hasPathSum from '../hasPathSum'
describe('路径总和 测试', () => {
  it('hasPathSum function', () => {
    //
  })
})
