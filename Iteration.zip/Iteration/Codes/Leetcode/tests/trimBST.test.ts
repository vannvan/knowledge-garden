/*
 * Description: 669：修剪二叉搜索树
 * Url: https://leetcode.cn/problems/trim-a-binary-search-tree/
 * Created: 2023-04-04 22:35:36
 * Author: van
 * Email : adoerww@gamil.com
 * -----
 * Last Modified: 2023-03-03 11:10:10
 * Modified By: van
 * -----
 * Copyright (c) 2023 https://github.com/vannvan
 */
import trimBST from '../trimBST' 
describe('修剪二叉搜索树 测试', () => { 
	it('trimBST function', () => { 
expect(trimBST([1,0,2],1
2))
expect(trimBST([3,0,4,null,2,null,null,1],1
3)) 
	}) 
})
